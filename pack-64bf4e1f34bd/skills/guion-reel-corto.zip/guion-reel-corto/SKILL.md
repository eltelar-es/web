---
name: guion-reel-corto
description: Escribe el guion de un reel o vídeo corto de unos 30 segundos con gancho, ritmo y llamada a la acción, en español. Úsala cuando el usuario quiera un guion para Instagram, TikTok o Shorts, o dudas sobre si un tema funcionará.
---

# Guion de reel corto

## 1. Filtra el tema antes de escribir
Un tema funciona si cumple las cuatro: (a) lo puede usar cualquiera desde el móvil o el navegador hoy, (b) ahorra dinero o tiempo a una persona normal, (c) se entiende en 2 segundos sin ser técnico, (d) el gancho es del tipo «deja de pagar por X», «lo estás haciendo mal» o «función escondida de [herramienta conocida]». Si solo sirve a quien programa, a quien tiene un Mac concreto o a creadores de contenido, avisa de que alcanzará poco.

## 2. Estructura (≈85 palabras para 30 s)
- **Segundo 0-2: gancho visual y de texto.** El resultado o el problema ya a la vista, legible sin sonido. Las frases de bienvenida no sirven.
- **2-25 s: 3-5 ideas con conectores**: «Primero…», «Otro…», «Luego…», «Además…», «Y por último…». Evita las listas del tipo «El uno… El dos… El tres…».
- **Cierre**: una frase para guardar o mandar («Mándaselo a quien lo necesite») y la palabra clave si hay automatización de comentarios.

## 3. Reglas de escritura
- Frases cortas, habladas, de 4-12 palabras. Cada trozo de subtítulo, de 2 a 4 palabras con sentido propio.
- Cifras concretas y comprobables. No prometas resultados que no puedas garantizar.
- Di la palabra clave del tema en voz alta: ayuda a que lo encuentren.
- Si la voz es de un servicio de voz, **no la aceleres ni la proceses**: da la velocidad con escenas más cortas y más cambios de imagen, no tocando el audio.

## 4. Texto del post
Las primeras 125 letras llevan la palabra clave y el beneficio. Máximo 5 hashtags. Si hay datos, la fecha de comprobación.

Entrega: guion con tiempos, texto en pantalla de cada escena, texto del post y una línea con la métrica que mirarías (cuántos se van en los primeros 3 segundos).

Estas son las pautas que seguimos; no garantizan un resultado, porque el algoritmo cambia.
