---
name: portada-carrusel-instagram
description: Diseña la portada de un carrusel de Instagram que se ve (foto brillante, personas recortadas, logos sueltos, titular corto) y evita errores de licencias y repeticiones. Úsala cuando el usuario pida la portada o el primer slide de un carrusel, o quiera que sus posts se vean más profesionales.
---

# Portada de carrusel (la que usamos en El Telar)

La portada decide si alguien desliza. Es una foto grande y un titular claro. Nada de portadas solo de texto.

## Receta
1. **Formato 1080×1350** (4:5). Mantén lo importante en la zona central: Instagram recorta bordes.
2. **Foto brillante y cercana.** Retrato de cara o escena con una persona. Sube luz y contraste; no la oscurezcas ni le pongas un tinte de color. Un fondo de colores inventados detrás de una persona recortada queda artificial: usa la foto con su fondo real.
3. **Logos de las marcas del tema, sueltos por la imagen**, no alineados en una columna: tamaños distintos (de 120 a 400 px), algo girados (±12°), uno gigante detrás o junto al hombro y otro pequeño en una esquina. Que «floten», que no estén pegados al borde derecho.
4. **Titular de 8-14 palabras** en mayúsculas con una frase resaltada en un solo color. Debe coincidir con la persona y con los logos de la foto (si sale Nvidia, el titular habla de chips, no de otra cosa) y con lo que de verdad cuenta el carrusel.
5. **Variedad.** No repitas persona, composición ni pareja de logos en 5 publicaciones seguidas. Alterna: un solo retrato, un «X contra Y», una escena sin cara famosa, un recorte con logo gigante, un primer plano.

## Qué foto usar
- Personas conocidas: solo fotos con licencia libre (Creative Commons o dominio público) con el crédito en el texto del post. No copies la foto de otra cuenta.
- Si usas una imagen generada con IA, **dilo**: activa la etiqueta de IA de Instagram y añade «Imagen generada con IA» en el texto.
- Un producto o un lugar es más seguro que una persona en noticias delicadas.

## Antes de publicar, comprueba
- ¿Se lee el titular en el móvil, sin zoom?
- ¿La foto coincide con lo que dice el carrusel?
- ¿Está el crédito en el texto del post?
- ¿Se repite algo de las últimas 5 portadas?

Entrega: descripción de la portada (foto, logos con tamaño y posición, titular, crédito) y, si el usuario lo pide, el HTML/CSS para generarla.
