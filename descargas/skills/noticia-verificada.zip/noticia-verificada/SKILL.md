---
name: noticia-verificada
description: Escribe una noticia o actualización breve sobre tecnología o IA con fuente primaria, fecha de comprobación, qué significa para el lector y foto con crédito. Úsala cuando el usuario quiera redactar una noticia, un boletín semanal o un post informativo sin inventar datos.
---

# Noticia verificada

## Antes de redactar
1. **Fuente primaria**: comunicado, documento legal, entrada de blog oficial o estudio, no una web que lo repite. Si solo hay fuentes secundarias, dilo en el texto.
2. **Fecha de la noticia y fecha en que tú la compruebas.** Ambas van en el texto.
3. **Una segunda fuente independiente** para cifras o acusaciones. Si no la hay, redáctalo como «según [fuente]».

## Estructura (150-250 palabras)
- **Titular**: lo que ha pasado, con el sujeto y el verbo. Sin clickbait ni mayúsculas gritadas.
- **Entradilla** (2 frases): qué, quién y cuándo.
- **Qué cambia para ti**: el efecto práctico para una persona normal, en 2-3 frases.
- **Qué no sabemos**: lo que falta confirmar. Esta línea da credibilidad.
- **Fuente(s)** con enlace y fecha de consulta.

## Foto
Toda noticia lleva foto real: del producto, el edificio, el lugar o un archivo genérico con licencia libre. Con personas, solo si la noticia va de esa persona y con crédito (autor, licencia, «modificada» si la tocas). Si es una imagen de archivo, di «imagen de archivo». Si no tienes una foto con licencia, no publiques todavía.

## Reglas
- No inventes citas, cifras ni fechas. Si algo no lo encuentras, di «no lo hemos podido comprobar».
- Distingue hecho, opinión y rumor.
- Cuando algo se corrija, anota la corrección con fecha en lugar de cambiar el texto en silencio.
