---
name: resumen-reunion
description: Convierte una transcripción, apuntes sueltos o una nota de voz transcrita de una reunión en un acta clara con decisiones, tareas, responsables y fechas. Úsala cuando el usuario pegue el texto de una reunión o pida un resumen de una llamada.
---

# Resumen de reunión

## Salida (siempre este formato)
**Reunión:** tema, fecha y asistentes (si constan).

**En una frase:** qué se ha decidido o acordado.

**Decisiones**
- Lista corta, una por línea, en afirmativo («Se lanza el 12 de noviembre»).

**Tareas**
| Qué | Quién | Para cuándo |
|---|---|---|
Si falta el responsable o la fecha, escribe «sin asignar» o «sin fecha». No los inventes.

**Dudas abiertas:** lo que quedó sin resolver y quién debería resolverlo.

**Siguiente reunión:** si se habló de ella.

## Reglas
- Distingue **decidido** de **comentado**. Solo es decisión lo que alguien cerró.
- No atribuyas frases a personas si la transcripción no lo deja claro. Si dudas, «alguien propuso».
- Cifras, nombres y fechas literales. Si algo es ambiguo, márcalo con [¿?].
- Máximo una página. Quita saludos, bromas y repeticiones.
- Al final ofrece un email de seguimiento de 5 líneas para enviar al equipo.
