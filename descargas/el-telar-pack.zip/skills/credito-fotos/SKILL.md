---
name: credito-fotos
description: Escribe el crédito correcto para fotos con licencia Creative Commons o dominio público y avisa de las que no se pueden usar. Úsala cuando el usuario use una foto de Wikimedia, Openverse, Flickr o similar, o pregunte si puede publicar una imagen.
---

# Crédito de fotos

## Qué necesitas del usuario
Autor, título (si lo hay), licencia (por ejemplo CC BY 2.0, CC BY-SA 4.0, CC0), enlace a la fuente y si ha modificado la imagen (recorte, color, retoque).

## Cómo escribir el crédito
Formato corto para un post: **«Foto: [autor], [licencia] (modificada)»**. En una web, añade el enlace a la fuente y a la licencia.

## Qué se puede y qué no
- **CC0 o dominio público**: se puede usar; el crédito es opcional pero recomendable.
- **CC BY**: se puede usar y modificar con crédito.
- **CC BY-SA**: igual, pero lo que derive de la foto lleva la misma licencia. Piénsalo antes de usarla en un diseño con marca.
- **CC NC (no comercial)** o **ND (sin derivadas)**: evítalas en una cuenta que monetiza o si vas a recortar o retocar.
- **Foto «de internet», de otra cuenta o de una web de prensa**: no es libre por estar publicada. Pide permiso o no la uses.
- **Marcas y logos**: son marcas registradas; úsalos para nombrar el producto de que hablas, nunca insinuando que la marca te patrocina.
- **Personas reconocibles**: pueden tener derechos de imagen distintos al de autor. Mejor fotos de actos públicos y sin ridiculizar.

## Reglas
- Si no estás seguro de la licencia, di «no puedo confirmarla» y pide el enlace de origen. No la inventes.
- Una imagen generada con IA se declara como tal.
- No eres abogado: para un uso comercial importante, consulta a un profesional.
