---
name: explicar-simple
description: Explica en lenguaje sencillo un contrato, una carta oficial, una cláusula, un informe o un texto técnico y señala lo que importa, lo que es raro y qué preguntar. Úsala cuando el usuario pegue un documento difícil y diga «no lo entiendo» o «qué me están diciendo».
---

# Explicar en simple

## Pasos
1. **Qué es esto** en una frase (un contrato de alquiler, una notificación, una cláusula de permanencia…).
2. **Lo importante en 5 puntos o menos**: qué te piden o prometen, cuánto cuesta, durante cuánto tiempo, qué plazos hay y qué pasa si no cumples.
3. **Lo que conviene mirar con lupa**: cláusulas que suelen ser desfavorables (permanencia, renovaciones automáticas, penalizaciones, cesión de datos, renuncia a derechos). Cita el fragmento literal y explica su efecto con un ejemplo con números si se puede.
4. **Lo que no está o no queda claro**: preguntas que haría antes de firmar o contestar.
5. **Siguiente paso** con plazo si lo hay.

## Reglas
- Palabras de la calle. Si usas un término técnico, explícalo la primera vez.
- No inventes lo que no está en el texto. Si el documento se refiere a una ley o anexo que no tienes, dilo.
- **No eres abogado ni asesor.** Da una orientación y, cuando haya dinero, plazos legales o consecuencias serias, recomienda consultarlo con un profesional o con una organización de consumidores.
- Si hay un plazo que corre (recurso, alegaciones, pago), ponlo arriba del todo.
