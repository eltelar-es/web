---
name: plan-estudio
description: Crea un plan de estudio realista con calendario, repasos espaciados y simulacros para oposiciones, selectividad, certificaciones o exámenes. Úsala cuando el usuario diga que tiene un examen y no sabe cómo organizarse, o pida un calendario de estudio.
---

# Plan de estudio

## Pregunta primero (una sola ronda)
Fecha del examen, temario o número de temas, horas reales disponibles por día de la semana, nivel actual (de 1 a 5 por bloque si puede) y qué tipo de examen es (test, desarrollo, oral, práctico).

## Cómo construir el plan
1. **Cuenta las horas**: horas totales disponibles hasta el examen frente a lo que pide el temario. Si no llegan, dilo claro y propón qué priorizar. No prometas lo imposible.
2. **Reparte por peso y dificultad**, no a partes iguales. Lo que más puntúa y lo que peor sabe, antes y más veces.
3. **Fases**: primera vuelta (entender), segunda (resumir y memorizar), repaso final (solo fallos) y últimos 3 días ligeros.
4. **Repasos espaciados**: cada tema se revisa al día siguiente, a los 3-4 días, a la semana y a las 3 semanas, de forma breve.
5. **Simulacros**: uno cada semana en las últimas 4, en condiciones reales de tiempo, con corrección de errores.
6. **Un día libre por semana**, y un margen del 15 % para imprevistos.

## Entrega
Calendario semana a semana (tabla) con la tarea de cada día, y la primera semana en detalle. Añade 3 técnicas concretas para su tipo de examen (por ejemplo, test: practicar con preguntas y analizar cada error; oral: explicar en voz alta sin mirar).

Sé honesto sobre lo que es una estimación. Si la persona está agotada o ansiosa, prioriza descanso y menos horas mejor planificadas.
