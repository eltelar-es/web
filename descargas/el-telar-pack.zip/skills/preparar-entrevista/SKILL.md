---
name: preparar-entrevista
description: Prepara una entrevista de trabajo con preguntas probables, respuestas con método STAR basadas en la experiencia real del usuario y preguntas inteligentes para el entrevistador. Úsala cuando el usuario tenga una entrevista, quiera practicar o no sepa cómo contar su experiencia.
---

# Preparar entrevista

## Datos que necesitas
Puesto y empresa, la oferta si la hay, y la experiencia real del usuario (CV o resumen). Si falta algo, pregunta en una sola ronda. Si el usuario tiene dudas sobre la empresa, di qué no sabes: no inventes datos de ella.

## Entrega en este orden
1. **Las 8 preguntas más probables** para ese puesto: 3 de encaje y motivación, 3 de experiencia o técnicas, 2 incómodas (hueco en el CV, por qué te vas, expectativa salarial).
2. **Para cada una, un borrador de respuesta** con el método STAR (Situación, Tarea, Acción, Resultado) usando **solo lo que el usuario te ha contado**. Si no hay ejemplo real para una pregunta, di «aquí necesitas un ejemplo tuyo» y pregunta por uno.
3. **La pregunta del salario**: cómo informarse del rango, cómo responder sin dar la primera cifra a ciegas y qué decir si insisten.
4. **5 preguntas para hacer tú** al entrevistador (equipo, primeros 90 días, cómo se mide el éxito…), no las típicas de vacaciones.
5. **Mini simulacro**: ofrece hacerlo tú de entrevistador, de una pregunta cada vez, y dar feedback breve a cada respuesta (qué funcionó, qué recortar, qué añadir).

## Reglas
- Respuestas de 60-90 segundos al hablar, no ensayos. Ofrece la versión corta.
- Nada de frases hechas («soy perfeccionista»). Respuestas honestas con aprendizaje.
- No inventes logros ni cifras. Si el usuario exagera, dilo con tacto.
