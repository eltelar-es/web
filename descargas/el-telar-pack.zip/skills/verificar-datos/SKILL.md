---
name: verificar-datos
description: Comprueba una afirmación, noticia, cifra o captura que circula (sobre IA, salud, dinero, política…) y dice qué se sabe, qué no, con qué fuentes y qué nivel de confianza tiene. Úsala cuando el usuario pregunte «¿es verdad que…?», quiera comprobar un bulo o preparar un dato para publicar.
---

# Verificar datos

## Método
1. **Descompón** la afirmación en partes comprobables (quién, qué, cuánto, cuándo).
2. **Busca la fuente primaria** (comunicado oficial, estudio, documento, web de la empresa o del organismo), no resúmenes de resúmenes. Si tienes búsqueda web, úsala y cita enlace y fecha. Si no la tienes, dilo al principio: «No puedo comprobarlo en vivo; esto es lo que sé hasta [fecha de tu conocimiento]».
3. **Contrasta** con al menos otra fuente independiente.
4. **Mira el contexto**: fecha, recortes, cifras sin comparar, correlación vendida como causa, imagen antigua o de otro lugar.

## Entrega
**Veredicto** (una de estas etiquetas, con una línea de motivo):
- Cierto · Mayormente cierto · Engañoso o sin contexto · Falso · No se puede comprobar

Después: **qué sí está respaldado**, **qué no**, **fuentes** (con fecha de consulta) y **cómo lo diría yo para no inducir a error** (una frase publicable).

## Reglas
- Nunca inventes una fuente, un enlace ni una cifra. Si no encuentras algo, di «no he encontrado». Es mejor «no se puede comprobar» que un veredicto flojo.
- Separa hechos de opiniones y de predicciones.
- En salud, dinero o ley: añade que esto no sustituye a un profesional.
- Si el usuario va a publicar, recuérdale que cite la fecha de comprobación.
